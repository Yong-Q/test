# Execution Support Matrix

This matrix describes the public execution algorithms. Internal kernels,
storage policies, and historical selector names are not separate public modes.

| Public request | Model boundary | Kokkos backends | Runtime artifact | LAMMPS |
|---|---|---|---|---|
| `direct` | Compact standard MACE and MACEField with admitted contracts; compatible compact MACE-MH-1 | Serial, OpenMP, CUDA, HIP | Standard two-interaction MACE/MACEField requires an R1 artifact; single-layer standard MACE runs without R1 specialization, but capacity may specialize M0/R0; MACE-MH-1 requires its generated program | Standard MACE and MACEField; R1 artifact required for two-interaction models, but not single-layer models; MACE-MH-1 is not supported |
| `non-compiled` | Compact standard MACE and MACEField; compatible compact MACE-MH-1 | Serial, OpenMP, CUDA, HIP | None | Compiler-free debug and compatibility checks only |
| `materialized` | Models in the original Symmetrix format (named v1 here) and retained numerical controls | Serial, OpenMP, CUDA, HIP | None | Original Symmetrix and supported standard MACE/MACEField controls |
| `auto` | Compatibility request resolved from model format and evaluator capability | As resolved above | As resolved above | Format-aware compatibility default |

The non-Kokkos evaluator selected by `use_kokkos=False` does not provide
prepared direct execution: a `direct` request resolves to serial non-compiled
execution with a warning. An explicit `materialized` request remains
materialized.

`generic` and `all_interactions` are deprecated aliases for `non-compiled`.
`factorized` and `direct_streamed` are compatibility aliases for `direct` and,
in the Python frontend, preserve the former throughput-oriented behavior by
changing an otherwise-`capacity` request to the `speed` profile. Use the
literal `direct` request for capacity behavior. These aliases do not emit a
deprecation warning. The removed `receiver_factorized` selector is rejected.

Ordinary MACE exposes energy, free energy, per-atom energies, forces, and
stress. MACEField additionally exposes polarization and admitted analytical
Born effective charge and polarizability calculations. On prepared and
generic execution the analytical response evaluates its radial splines inline
from coefficient tables instead of materializing edge-sized radial caches, so
response memory is dominated by node-sized adjoint tangents;
`SYMMETRIX_DEBUG_RESPONSE_MATERIALIZED_RADIAL=1` restores the former
materialized caches for diagnosis. Property, precision, and MPI qualification
can be narrower than implementation availability; dated benchmark reports
provide the evidence for a specific backend and workload.

`execution_profile="capacity"` and `"speed"` select resource objectives inside
the direct algorithm. `allow_fixed_workspace=True` separately permits bounded
tiled workspace for qualified ordinary MH0 standard MACE models on CUDA in
FP32 and FP64. MACEField and MACE-MH-1 do not support fixed-workspace plans.
These controls do not create additional execution modes.

LAMMPS `mpi_message_passing` supports the dual-layer fixed-workspace plan for
ordinary two-interaction standard MACE with CUDA FP32 or FP64 direct execution
and a precision-matched generated tiled R1 device artifact. The receiver- and
edge-sized workspace is bounded, while H1 and its adjoint remain sized to all
local and ghost feature nodes. HIP, field-coupled models, parameter gradients,
and execution observers are outside this qualification boundary.

See {doc}`/streamed_edge_execution` for the architecture, {doc}`/user/execution`
for user controls, and {doc}`/user/lammps` for the narrower LAMMPS boundary.
