"""Sphinx configuration for the Symmetrix-XL documentation."""

from datetime import date

project = "Symmetrix-XL"
copyright = f"{date.today().year}, Symmetrix-XL contributors"
author = "Symmetrix-XL contributors"
release = "0.1.1"

extensions = ["myst_parser"]
source_suffix = {".rst": "restructuredtext", ".md": "markdown"}
master_doc = "index"
exclude_patterns = ["_build"]
myst_enable_extensions = ["colon_fence", "deflist", "fieldlist"]
myst_heading_anchors = 3

html_theme = "furo"
html_title = "Symmetrix-XL"
html_baseurl = "https://bonan-group.github.io/symmetrix-xl/"
html_static_path = []
html_theme_options = {
    "source_repository": "https://github.com/bonan-group/symmetrix-xl/",
    "source_branch": "main",
    "source_directory": "docs/",
}
