import numpy as np
from pytest import approx, raises
from scipy.interpolate import CubicSpline

import symmetrix


def test_invalid_input():
    for h in [0.0, -1.0]:
        with raises(ValueError):
            symmetrix.CubicSpline(h, [0.0, 1.0], [0.0, 1.0])

    for values, derivs in [([], []), ([0.0], [0.0]), ([0.0, 1.0], [0.0])]:
        with raises(ValueError):
            symmetrix.CubicSpline(1.0, values, derivs)


def test_evaluate():
    # generate data
    r_cut = 5
    r, h = np.linspace(0, r_cut, 20, retstep=True)
    f = np.sin(r) * r**2 * (r_cut - r) ** 2
    # create splines
    scipy_spl = CubicSpline(r, f)
    d = scipy_spl.derivative()(r)
    spl = symmetrix.CubicSpline(h, f, d)
    # test equivalence
    r2 = np.linspace(0, r_cut, 1000)
    f2 = np.zeros(len(r2))
    for i, ri in enumerate(r2):
        f2[i] = spl.evaluate(ri)
    assert f2 == approx(scipy_spl(r2))
    # test out of bounds errors
    for r in [-1.0, r_cut + 1e-12, 9.0]:
        with raises(ValueError) as exception:
            spl.evaluate(r)
        assert str(exception.value).startswith(
            "Out of bounds in CubicSpline::evaluate."
        )


def test_evaluate_deriv():
    # generate data
    r_cut = 5
    r, h = np.linspace(0, r_cut, 20, retstep=True)
    f = np.sin(r) * r**2 * (r_cut - r) ** 2
    # create splines
    scipy_spl = CubicSpline(r, f)
    d = scipy_spl.derivative()(r)
    spl = symmetrix.CubicSpline(h, f, d)
    # test equivalence
    r2 = np.linspace(0, r_cut, 1000)
    f2 = np.zeros(len(r2))
    d2 = np.zeros(len(r2))
    for i, ri in enumerate(r2):
        f2[i], d2[i] = spl.evaluate_deriv(ri)
    assert f2 == approx(scipy_spl(r2))
    assert d2 == approx(scipy_spl.derivative()(r2))

    for r in [-1.0, r_cut + 1e-12, 9.0]:
        with raises(ValueError) as exception:
            _ = spl.evaluate_deriv(r)
        assert str(exception.value).startswith(
            "Out of bounds in CubicSpline::evaluate_deriv."
        )


def test_evaluate_deriv_divided():
    # generate data
    r_cut = 5
    r, h = np.linspace(0, r_cut, 20, retstep=True)
    f = np.sin(r) * r**2 * (r_cut - r) ** 2
    # create splines
    scipy_spl = CubicSpline(r, f)
    d = scipy_spl.derivative()(r)
    spl = symmetrix.CubicSpline(h, f, d)
    # test equivalence
    r2 = np.linspace(1e-6, r_cut, 1000)
    f2 = np.zeros(len(r2))
    d2 = np.zeros(len(r2))
    for i, ri in enumerate(r2):
        f2[i], d2[i] = spl.evaluate_deriv_divided(ri)
    assert f2 == approx(scipy_spl(r2))
    assert d2 == approx(scipy_spl.derivative()(r2) / r2)

    for r in [-1.0, 0.0, r_cut + 1e-12, 9.0]:
        with raises(ValueError) as exception:
            _ = spl.evaluate_deriv_divided(r)
        assert str(exception.value).startswith(
            "Out of bounds in CubicSpline::evaluate_deriv_divided."
        )
